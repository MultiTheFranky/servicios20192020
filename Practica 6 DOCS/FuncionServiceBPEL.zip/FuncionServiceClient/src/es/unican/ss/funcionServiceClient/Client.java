package es.unican.ss.funcionServiceClient;

import org.example.funcion.FuncionService;
import org.example.funcion.FuncionServicePortType;

public class Client {
	
	public static void main (String args[]) {
		FuncionService service = new FuncionService();
		
		//((BindingProvider) service).getRequestContext().put(Dispatch.ENDPOINT_ADDRESS_PROPERTY, "http://the serviceaddress");
		FuncionServicePortType port = service.getFuncionPort();
		
		System.out.println(port.calculaFuncion(1, 4));
		
		System.out.println(port.calculaFuncion(4, 4));
		
	}

}

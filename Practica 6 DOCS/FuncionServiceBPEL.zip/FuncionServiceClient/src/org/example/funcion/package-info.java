@javax.xml.bind.annotation.XmlSchema(namespace = "www.example.org/funcion", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.example.funcion;

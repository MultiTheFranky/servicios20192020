@javax.xml.bind.annotation.XmlSchema(namespace = "http://multiplicaservice.example.org/")
package org.example.multiplicaservice;

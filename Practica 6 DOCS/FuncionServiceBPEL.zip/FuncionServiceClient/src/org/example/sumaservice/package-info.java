@javax.xml.bind.annotation.XmlSchema(namespace = "http://sumaservice.example.org/")
package org.example.sumaservice;

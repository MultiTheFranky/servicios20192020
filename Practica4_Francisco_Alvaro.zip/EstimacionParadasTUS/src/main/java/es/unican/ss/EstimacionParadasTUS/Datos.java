package es.unican.ss.EstimacionParadasTUS;

import java.util.ArrayList;

public class Datos {
    /**
     * Atributos
     */
    private String nombreRuta;
    private int estimacion1;
    private int estimacion2;

    public String getNombreRuta() {
        return this.nombreRuta;
    }

    public void setNombreRuta(String nombreRuta) {
        this.nombreRuta = nombreRuta;
    }

    public int getEstimacion1() {
        return this.estimacion1;
    }

    public void setEstimacion1(int estimacion1) {
        this.estimacion1 = estimacion1;
    }

    public int getEstimacion2() {
        return this.estimacion2;
    }

    public void setEstimacion2(int estimacion2) {
        this.estimacion2 = estimacion2;
    }

    /**
     * Constructor
     */
    public Datos() {
    }

}
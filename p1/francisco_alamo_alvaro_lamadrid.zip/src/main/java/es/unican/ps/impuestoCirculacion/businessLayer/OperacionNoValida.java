package es.unican.ps.impuestoCirculacion.businessLayer;

public class OperacionNoValida extends Exception {

	public OperacionNoValida(String string) {
		super(string);
	}

}

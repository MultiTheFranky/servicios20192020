//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci�n de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2020.02.04 a las 04:18:59 PM CET 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.unican.es/ss/ImpuestoCirculacion", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package es.unican.ps.impuestoCirculacion.domain;

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.unican.es/ss/EstimacionTUSBPEL", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package es.unican.ss.estimaciontusbpel;
